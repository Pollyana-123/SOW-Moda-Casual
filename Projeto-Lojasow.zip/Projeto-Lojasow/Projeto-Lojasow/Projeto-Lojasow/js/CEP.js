
const campoCep = document.getElementById("cep");
const botaoConsultar = document.getElementById("consultarCep");
const resultadoCep = document.getElementById("resultadoCep");

botaoConsultar.addEventListener("click", consultarCEP);

async function consultarCEP() {

    const cep = campoCep.value.replace(/\D/g, "");

    if (cep.length !== 8) {
        resultadoCep.textContent = "Digite um CEP válido com 8 números.";
        return;
    }

    resultadoCep.textContent = "Consultando CEP...";

    try {

        const resposta = await fetch(
            `https://viacep.com.br/ws/${cep}/json/`
        );

        if (!resposta.ok) {
            throw new Error("Erro ao consultar o CEP.");
        }

        const dados = await resposta.json();

        if (dados.erro) {
            resultadoCep.textContent = "CEP não encontrado.";
            return;
        }

        resultadoCep.innerHTML = `
            <p><strong>Endereço:</strong> ${dados.logradouro || "Não informado"}</p>
            <p><strong>Bairro:</strong> ${dados.bairro || "Não informado"}</p>
            <p><strong>Cidade:</strong> ${dados.localidade}</p>
            <p><strong>Estado:</strong> ${dados.uf}</p>
        `;

    } catch (erro) {

        resultadoCep.textContent =
            "Não foi possível consultar o CEP. Verifique sua conexão e tente novamente.";

    }
}
