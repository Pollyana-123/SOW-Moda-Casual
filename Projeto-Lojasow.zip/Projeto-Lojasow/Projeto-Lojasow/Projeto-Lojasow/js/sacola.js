const produtosSacola = document.getElementById("produtos-sacola");
const subtotalElemento = document.getElementById("subtotal");
const totalElemento = document.getElementById("total");

let carrinho = JSON.parse(localStorage.getItem("carrinho")) || [];

function atualizarSacola() {

    produtosSacola.innerHTML = "";

    if (carrinho.length === 0) {
        produtosSacola.innerHTML = "<p>Sua sacola está vazia.</p>";

        subtotalElemento.textContent = "R$ 0,00";
        totalElemento.textContent = "R$ 0,00";

        return;
    }

    let subtotal = 0;

    carrinho.forEach((produto, indice) => {

        const totalProduto = produto.preco * produto.quantidade;

        subtotal += totalProduto;

        const item = document.createElement("div");

        item.classList.add("item-sacola");

        item.innerHTML = `
            <img src="${produto.imagem}" alt="${produto.nome}">

            <div class="informacoes-sacola">
                <h3>${produto.nome}</h3>

                <p>Cor: ${produto.cor}</p>
                <p>Tamanho: ${produto.tamanho}</p>

                <p>Preço: ${produto.preco.toLocaleString("pt-BR", {
                    style: "currency",
                    currency: "BRL"
                })}</p>

                <div class="quantidade">
                    <button class="diminuir" data-indice="${indice}">-</button>

                    <span>${produto.quantidade}</span>

                    <button class="aumentar" data-indice="${indice}">+</button>
                </div>

                <button class="remover" data-indice="${indice}">
                    REMOVER
                </button>
            </div>
        `;

        produtosSacola.appendChild(item);
    });

    subtotalElemento.textContent = subtotal.toLocaleString("pt-BR", {
        style: "currency",
        currency: "BRL"
    });

    totalElemento.textContent = subtotalElemento.textContent;

    document.querySelectorAll(".aumentar").forEach((botao) => {
        botao.addEventListener("click", () => {

            const indice = Number(botao.dataset.indice);

            carrinho[indice].quantidade++;

            salvarCarrinho();
        });
    });

    document.querySelectorAll(".diminuir").forEach((botao) => {
        botao.addEventListener("click", () => {

            const indice = Number(botao.dataset.indice);

            if (carrinho[indice].quantidade > 1) {
                carrinho[indice].quantidade--;
            }

            salvarCarrinho();
        });
    });

    document.querySelectorAll(".remover").forEach((botao) => {
        botao.addEventListener("click", () => {

            const indice = Number(botao.dataset.indice);

            carrinho.splice(indice, 1);

            salvarCarrinho();
        });
    });
}

function salvarCarrinho() {

    localStorage.setItem("carrinho", JSON.stringify(carrinho));

    atualizarSacola();
}

document.getElementById("finalizarCompra").addEventListener("click", () => {

    if (carrinho.length === 0) {
        alert("Sua sacola está vazia.");
        return;
    }

    window.location.href = "pagina-final.html";
});

atualizarSacola();