const listaFinal = document.getElementById("lista-final");
const valorFinal = document.getElementById("valor-final");
const formulario = document.getElementById("formFinalizacao");
const botaoFinalizar = document.querySelector(".botao-finalizar");

let carrinho = JSON.parse(localStorage.getItem("carrinho")) || [];

let total = 0;

function atualizarResumo() {

    listaFinal.innerHTML = "";
    total = 0;

    if (carrinho.length === 0) {

        listaFinal.innerHTML = "<p>Sua sacola está vazia.</p>";

        valorFinal.textContent = "R$ 0,00";

        botaoFinalizar.disabled = true;

        return;
    }

    carrinho.forEach((produto) => {

        total += Number(produto.preco) * Number(produto.quantidade);

        const item = document.createElement("div");
        item.classList.add("produto-final");

        const imagem = document.createElement("img");
        imagem.src = produto.imagem;
        imagem.alt = produto.nome;

        const informacoes = document.createElement("div");

        const nome = document.createElement("p");
        nome.textContent = produto.nome;

        const cor = document.createElement("p");
        cor.textContent = "Cor: " + produto.cor;

        const tamanho = document.createElement("p");
        tamanho.textContent = "Tamanho: " + produto.tamanho;

        const quantidade = document.createElement("p");
        quantidade.textContent = "Quantidade: " + produto.quantidade;

        const preco = document.createElement("p");

        preco.textContent = (Number(produto.preco) * Number(produto.quantidade))
            .toLocaleString("pt-BR", {
                style: "currency",
                currency: "BRL"
            });

        informacoes.appendChild(nome);
        informacoes.appendChild(cor);
        informacoes.appendChild(tamanho);
        informacoes.appendChild(quantidade);
        informacoes.appendChild(preco);

        item.appendChild(imagem);
        item.appendChild(informacoes);

        listaFinal.appendChild(item);

    });

    valorFinal.textContent = total.toLocaleString("pt-BR", {
        style: "currency",
        currency: "BRL"
    });

    botaoFinalizar.disabled = false;

}

formulario.addEventListener("submit", (event) => {

    event.preventDefault();

    if (carrinho.length === 0) {

        alert("Sua sacola está vazia.");

        return;
    }

    if (!formulario.checkValidity()) {

        formulario.reportValidity();

        return;
    }

    const numeroPedido = "SOW" + Date.now().toString().slice(-8);

    sessionStorage.setItem("numeroPedido", numeroPedido);

    sessionStorage.setItem("valorPedido", total.toFixed(2));

    localStorage.removeItem("carrinho");

    window.location.href = "conclusao.html";

});

atualizarResumo();
