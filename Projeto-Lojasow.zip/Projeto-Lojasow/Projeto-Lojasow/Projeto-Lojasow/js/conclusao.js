const numeroPedido = sessionStorage.getItem("numeroPedido");

const elementoPedido = document.getElementById("numeroPedido");

if (elementoPedido) {
    elementoPedido.textContent =
        numeroPedido || "Pedido não identificado";
}