
const formularioPesquisa = document.getElementById("formPesquisa");
const campoPesquisa = document.getElementById("buscaProdutos");
const sugestoesPesquisa = document.getElementById("sugestoesPesquisa");

const produtos = [
    {
        categoria: "Vestido",
        pagina: "vestidos.html",
        cores: ["Preto", "Branco", "Azul", "Verde", "Vermelho"]
    },
    {
        categoria: "Calça",
        pagina: "calca.html",
        cores: ["Preto", "Bordo", "Marrom"]
    },
    {
        categoria: "Camisa",
        pagina: "camisa.html",
        cores: ["Preto", "Azul", "Rosa"]
    },
    {
        categoria: "Camiseta",
        pagina: "camiseta.html",
        cores: ["Preto", "Branca", "Marrom"]
    },
    {
        categoria: "Jaqueta",
        pagina: "jaqueta.html",
        cores: ["Preto", "Bege", "Bordô"]
    },
    {
        categoria: "Saia",
        pagina: "saia.html",
        cores: ["Preto", "Verde", "Bordô"]
    }
];

function normalizar(texto) {
    return texto
        .toLowerCase()
        .normalize("NFD")
        .replace(/[\u0300-\u036f]/g, "")
        .trim();
}

function mostrarSugestoes() {
    const pesquisa = normalizar(campoPesquisa.value);

    sugestoesPesquisa.innerHTML = "";

    if (pesquisa === "") {
        sugestoesPesquisa.classList.remove("ativa");
        return;
    }

    const resultados = [];

    produtos.forEach(function(produto) {
        const nomeCategoria = normalizar(produto.categoria);

        if (
            nomeCategoria.includes(pesquisa) ||
            pesquisa.includes(nomeCategoria)
        ) {
            produto.cores.forEach(function(cor) {
                resultados.push({
                    nome: produto.categoria + " " + cor,
                    pagina: produto.pagina,
                    cor: cor
                });
            });
        } else {
            produto.cores.forEach(function(cor) {
                const nomeCompleto = normalizar(produto.categoria + " " + cor);

                if (nomeCompleto.includes(pesquisa)) {
                    resultados.push({
                        nome: produto.categoria + " " + cor,
                        pagina: produto.pagina,
                        cor: cor
                    });
                }
            });
        }
    });

    if (resultados.length === 0) {
        sugestoesPesquisa.classList.remove("ativa");
        return;
    }

    resultados.forEach(function(produto) {
        const opcao = document.createElement("a");

        opcao.textContent = produto.nome;
        opcao.href = produto.pagina + "?cor=" + encodeURIComponent(produto.cor);

        sugestoesPesquisa.appendChild(opcao);
    });

    sugestoesPesquisa.classList.add("ativa");
}

campoPesquisa.addEventListener("input", mostrarSugestoes);

formularioPesquisa.addEventListener("submit", function(event) {
    event.preventDefault();

    const primeiraSugestao = sugestoesPesquisa.querySelector("a");

    if (primeiraSugestao) {
        window.location.href = primeiraSugestao.href;
    }
});

document.addEventListener("click", function(event) {
    if (!event.target.closest(".pesquisa-container")) {
        sugestoesPesquisa.classList.remove("ativa");
    }
});
