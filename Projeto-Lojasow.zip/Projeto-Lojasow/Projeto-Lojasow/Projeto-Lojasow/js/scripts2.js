const abrirMedidas = document.getElementById("abrirMedidas");
const fecharMedidas = document.getElementById("fecharMedidas");
const modalMedidas = document.getElementById("modalMedidas");

abrirMedidas.addEventListener("click", () => {
    modalMedidas.showModal();
});

fecharMedidas.addEventListener("click", () => {
    modalMedidas.close();
});

const tamanhos = document.querySelectorAll(".opcoes-tamanho button");

let tamanhoSelecionado = "";

tamanhos.forEach((botao) => {
    botao.addEventListener("click", () => {
        tamanhos.forEach((item) => {
            item.classList.remove("selecionado");
        });

        botao.classList.add("selecionado");
        tamanhoSelecionado = botao.textContent.trim();
    });
});

const opcoesCores = document.querySelectorAll(".opcoes-cores button");
const corSelecionada = document.getElementById("corSelecionada");
const imagemProduto = document.getElementById("imagemProduto");

let corAtual = "Preto";

opcoesCores.forEach((botao) => {
    botao.addEventListener("click", () => {
        opcoesCores.forEach((item) => {
            item.classList.remove("selecionado");
        });

        botao.classList.add("selecionado");
        corAtual = botao.dataset.cor;
corSelecionada.textContent = corAtual;

if (imagemProduto && botao.dataset.imagem) {
    imagemProduto.src = botao.dataset.imagem;
    imagemProduto.alt = "Vestido " + corAtual;
}
    });
});

const botaoComprar = document.getElementById("comprar");

botaoComprar.addEventListener("click", () => {

    if (tamanhoSelecionado === "") {
        alert("Selecione um tamanho antes de comprar.");
        return;
    }

    const nomeProduto = document.querySelector(".informacoes-produto h2").textContent;
    const precoTexto = document.querySelector(".preco strong").textContent;

    const precoProduto = Number(
        precoTexto.replace(/[^\d,]/g, "").replace(",", ".")
    );

    const produto = {
        id: nomeProduto.toLowerCase().normalize("NFD").replace(/[\u0300-\u036f]/g, "").replace(/\s+/g, "-"),
        nome: nomeProduto,
        preco: precoProduto,
        imagem: document.querySelector(".galeria-produto img").getAttribute("src"),
        tamanho: tamanhoSelecionado,
        cor: corAtual,
        quantidade: 1
    };

    let carrinho = JSON.parse(localStorage.getItem("carrinho")) || [];

    const produtoExistente = carrinho.find((item) =>
        item.id === produto.id &&
        item.tamanho === produto.tamanho &&
        item.cor === produto.cor
    );

    if (produtoExistente) {
        produtoExistente.quantidade++;
    } else {
        carrinho.push(produto);
    }

    localStorage.setItem("carrinho", JSON.stringify(carrinho));

    window.location.href = "pagina-compra.html";

});


const parametrosURL = new URLSearchParams(window.location.search);
const corPesquisada = parametrosURL.get("cor");

if (corPesquisada) {
    function normalizarCor(texto) {
        return texto
            .toLowerCase()
            .normalize("NFD")
            .replace(/[\u0300-\u036f]/g, "")
            .trim();
    }

    const botaoCorEncontrado = Array.from(opcoesCores).find((botao) => {
        return normalizarCor(botao.dataset.cor) === normalizarCor(corPesquisada);
    });

    if (botaoCorEncontrado) {
        botaoCorEncontrado.click();
    }
}
