
const formulario = document.getElementById("formContato");
const retorno = document.getElementById("retorno-contato");

formulario.addEventListener("submit", function(event) {

    event.preventDefault();

    retorno.textContent = "Mensagem enviada com sucesso! Obrigada por entrar em contato com a SOW.";

    formulario.reset();

});
